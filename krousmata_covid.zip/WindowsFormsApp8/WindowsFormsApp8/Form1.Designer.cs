﻿
namespace WindowsFormsApp8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.εισαγωγήΚρούσματοςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.προβολήΚρουσμάτωνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.διαγραφήToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.τροποποίησηΚρούσματοςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.αναζήτησηToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.εισάγετεIdΚρούσματοςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.εισάγετεEmailΚρούσματοςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.στατιστικάToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.άνδρεςΓυναίκεςToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.πλήθοςΑνδρώνToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.εισαγωγήΚρούσματοςToolStripMenuItem,
            this.προβολήΚρουσμάτωνToolStripMenuItem,
            this.διαγραφήToolStripMenuItem,
            this.τροποποίησηΚρούσματοςToolStripMenuItem,
            this.αναζήτησηToolStripMenuItem,
            this.στατιστικάToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(940, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // εισαγωγήΚρούσματοςToolStripMenuItem
            // 
            this.εισαγωγήΚρούσματοςToolStripMenuItem.Name = "εισαγωγήΚρούσματοςToolStripMenuItem";
            this.εισαγωγήΚρούσματοςToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.εισαγωγήΚρούσματοςToolStripMenuItem.Text = "Εισαγωγή κρούσματος";
            this.εισαγωγήΚρούσματοςToolStripMenuItem.Click += new System.EventHandler(this.εισαγωγήΚρούσματοςToolStripMenuItem_Click);
            // 
            // προβολήΚρουσμάτωνToolStripMenuItem
            // 
            this.προβολήΚρουσμάτωνToolStripMenuItem.Name = "προβολήΚρουσμάτωνToolStripMenuItem";
            this.προβολήΚρουσμάτωνToolStripMenuItem.Size = new System.Drawing.Size(177, 24);
            this.προβολήΚρουσμάτωνToolStripMenuItem.Text = "Προβολή κρουσμάτων";
            this.προβολήΚρουσμάτωνToolStripMenuItem.Click += new System.EventHandler(this.προβολήΚρουσμάτωνToolStripMenuItem_Click);
            // 
            // διαγραφήToolStripMenuItem
            // 
            this.διαγραφήToolStripMenuItem.Name = "διαγραφήToolStripMenuItem";
            this.διαγραφήToolStripMenuItem.Size = new System.Drawing.Size(91, 24);
            this.διαγραφήToolStripMenuItem.Text = "Διαγραφή";
            this.διαγραφήToolStripMenuItem.Click += new System.EventHandler(this.διαγραφήToolStripMenuItem_Click);
            // 
            // τροποποίησηΚρούσματοςToolStripMenuItem
            // 
            this.τροποποίησηΚρούσματοςToolStripMenuItem.Name = "τροποποίησηΚρούσματοςToolStripMenuItem";
            this.τροποποίησηΚρούσματοςToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.τροποποίησηΚρούσματοςToolStripMenuItem.Text = "Τροποποίηση κρούσματος";
            this.τροποποίησηΚρούσματοςToolStripMenuItem.Click += new System.EventHandler(this.τροποποίησηΚρούσματοςToolStripMenuItem_Click);
            // 
            // αναζήτησηToolStripMenuItem
            // 
            this.αναζήτησηToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.εισάγετεIdΚρούσματοςToolStripMenuItem,
            this.εισάγετεEmailΚρούσματοςToolStripMenuItem});
            this.αναζήτησηToolStripMenuItem.Name = "αναζήτησηToolStripMenuItem";
            this.αναζήτησηToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.αναζήτησηToolStripMenuItem.Text = "Αναζήτηση";
            // 
            // εισάγετεIdΚρούσματοςToolStripMenuItem
            // 
            this.εισάγετεIdΚρούσματοςToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox2});
            this.εισάγετεIdΚρούσματοςToolStripMenuItem.Name = "εισάγετεIdΚρούσματοςToolStripMenuItem";
            this.εισάγετεIdΚρούσματοςToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.εισάγετεIdΚρούσματοςToolStripMenuItem.Text = "Εισάγετε id κρούσματος:";
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(100, 27);
            this.toolStripTextBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolStripTextBox2_KeyDown);
            // 
            // εισάγετεEmailΚρούσματοςToolStripMenuItem
            // 
            this.εισάγετεEmailΚρούσματοςToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox3});
            this.εισάγετεEmailΚρούσματοςToolStripMenuItem.Name = "εισάγετεEmailΚρούσματοςToolStripMenuItem";
            this.εισάγετεEmailΚρούσματοςToolStripMenuItem.Size = new System.Drawing.Size(283, 26);
            this.εισάγετεEmailΚρούσματοςToolStripMenuItem.Text = "Εισάγετε email κρούσματος:";
            // 
            // toolStripTextBox3
            // 
            this.toolStripTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox3.Name = "toolStripTextBox3";
            this.toolStripTextBox3.Size = new System.Drawing.Size(100, 27);
            this.toolStripTextBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolStripTextBox3_KeyDown);
            // 
            // στατιστικάToolStripMenuItem
            // 
            this.στατιστικάToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem,
            this.άνδρεςΓυναίκεςToolStripMenuItem,
            this.πλήθοςΑνδρώνToolStripMenuItem});
            this.στατιστικάToolStripMenuItem.Name = "στατιστικάToolStripMenuItem";
            this.στατιστικάToolStripMenuItem.Size = new System.Drawing.Size(95, 24);
            this.στατιστικάToolStripMenuItem.Text = "Στατιστικά";
            // 
            // πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem
            // 
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox1});
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem.Name = "πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem";
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem.Size = new System.Drawing.Size(309, 26);
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem.Text = "πλήθος κρουσμάτων ανά ηλικία";
            this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem.Click += new System.EventHandler(this.πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 27);
            this.toolStripTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolStripTextBox1_KeyDown);
            // 
            // άνδρεςΓυναίκεςToolStripMenuItem
            // 
            this.άνδρεςΓυναίκεςToolStripMenuItem.Name = "άνδρεςΓυναίκεςToolStripMenuItem";
            this.άνδρεςΓυναίκεςToolStripMenuItem.Size = new System.Drawing.Size(309, 26);
            this.άνδρεςΓυναίκεςToolStripMenuItem.Text = "Πλήθος Γυναικών";
            this.άνδρεςΓυναίκεςToolStripMenuItem.Click += new System.EventHandler(this.άνδρεςΓυναίκεςToolStripMenuItem_Click);
            // 
            // πλήθοςΑνδρώνToolStripMenuItem
            // 
            this.πλήθοςΑνδρώνToolStripMenuItem.Name = "πλήθοςΑνδρώνToolStripMenuItem";
            this.πλήθοςΑνδρώνToolStripMenuItem.Size = new System.Drawing.Size(309, 26);
            this.πλήθοςΑνδρώνToolStripMenuItem.Text = "Πλήθος Ανδρών";
            this.πλήθοςΑνδρώνToolStripMenuItem.Click += new System.EventHandler(this.πλήθοςΑνδρώνToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::WindowsFormsApp8.Properties.Resources.coronavirus;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(940, 593);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Εφαρμογή καταγραφής κρουσμάτων Covid-19";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem εισαγωγήΚρούσματοςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem προβολήΚρουσμάτωνToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem διαγραφήToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem τροποποίησηΚρούσματοςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem αναζήτησηToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem στατιστικάToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem πλήθοςΚρουσμάτωνΑνάΗλικίαToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem άνδρεςΓυναίκεςToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem πλήθοςΑνδρώνToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem εισάγετεIdΚρούσματοςToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripMenuItem εισάγετεEmailΚρούσματοςToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox3;
    }
}

